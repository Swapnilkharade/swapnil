package com.jbk.SpringBoot.Employee.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootEmployeeProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
